package com.example.jessicacecilia.moviecatalogue.model;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Log;

import com.example.jessicacecilia.moviecatalogue.BuildConfig;
import com.example.jessicacecilia.moviecatalogue.MainActivity;
import com.example.jessicacecilia.moviecatalogue.R;
import com.example.jessicacecilia.moviecatalogue.database.DatabaseContract;
import com.example.jessicacecilia.moviecatalogue.entity.Movie;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.json.JSONObject;

import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;

import cz.msebera.android.httpclient.Header;

public class GetMovie {
    private static final String API_KEY = BuildConfig.ApiKey;

    public static final String EXTRA_IDENTIFIER = "extra title";

    private Context context;
    private ArrayList<Movie> movieList;
    private boolean isProcessFinished = false;
    private JSONObject responseObject;
    public static final String EXTRA_URL_TYPE = "url type";
    public static final String POSTER_URI = "http://image.tmdb.org/t/p/w185";
    private int urlType;
    private double totalProgress;
    private double progress;
    private boolean isMovieDetail;
    private String releaseReminderDate = "";

    public static final int NOW_SHOWING = 0;
    public static final int UPCOMING = 1;
    public static final int SEARCH_RESULT = 2;
    public static final int MOVIE_DETAIL = 3;
    public static final int FAVORITE = 4;
    public static final int RELEASE_REMINDER = 5;
    public static final int WIDGET = 6;

    //constructor specially for release reminder and widget
    public GetMovie() {

    }

    public GetMovie(Context context) {
        this.context = context;
    }

    public boolean processFinished() {
        return isProcessFinished;
    }

    public ArrayList<Movie> getMovieList() {
        return movieList;
    }

    public void query(int urlType, String identifier) { //fetching from network
        Log.d(MainActivity.TAG, "Query berjalan");

        isMovieDetail = false;
        this.urlType = urlType;
        AsyncHttpClient client = new AsyncHttpClient();
        String url = getUrl(identifier);
        movieList = new ArrayList<>();

        if (urlType == RELEASE_REMINDER) {
            releaseReminderDate = identifier;
        }

        Log.d(MainActivity.TAG, "Mencoba mengambil data dari " + url);

        if (isMovieDetail) {
            getSingleFromHTTP(url, client);
        } else {
            getListFromHTTP(url, client);
        }
    }

    //get list of movie from network
    private void getListFromHTTP(String url, AsyncHttpClient client) {
        client.get(url, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                try {
                    responseObject = new JSONObject(new String(responseBody));
                    int totalResult = responseObject.getInt("total_results");
                    Log.d(MainActivity.TAG, "Hasil pencarian: " + totalResult);

                    totalResult = (totalResult <= 20) ? totalResult : 20; //can only get 20.

                    progress = 100 / ((double) totalResult);
                    if (urlType == GetMovie.NOW_SHOWING || urlType == GetMovie.UPCOMING) {
                        progress /= 2;
                    }
                    totalProgress = 0;

                    // should be fixed later
                    //fetching movie
                    boolean found = false;
                    int i = 0;
                    while (i < totalResult && !found) {
                        String title = responseObject
                                .getJSONArray("results")
                                .getJSONObject(i)
                                .getString("title");
                        String date = responseObject
                                .getJSONArray("results")
                                .getJSONObject(i)
                                .getString("release_date");
                        if (urlType != RELEASE_REMINDER) {
                            String id = responseObject
                                    .getJSONArray("results")
                                    .getJSONObject(i)
                                    .getString("id");
                            String poster = responseObject
                                    .getJSONArray("results")
                                    .getJSONObject(i)
                                    .getString("poster_path");

                            String posterUri = POSTER_URI + poster;
                            String description = responseObject
                                    .getJSONArray("results")
                                    .getJSONObject
                                            (i).getString("overview");
                            String releaseDate = getDateFormatted(date);
                            Bitmap imgPoster = null;
                            if (poster != null) {
                                Log.d(MainActivity.TAG, "poster masuk");
                                imgPoster = getPosterBitmap(posterUri);
                            }

                            boolean isFavorite = false;
                            Cursor cursor = context.getContentResolver().query(
                                    Uri.parse(DatabaseContract.CONTENT_URI + "/" + id),
                                    null,
                                    null,
                                    null,
                                    null);

                            if (cursor != null) {
                                if (cursor.moveToFirst()) {
                                    isFavorite = true;
                                }
                            }

                            movieList.add(new Movie(id, poster, imgPoster, title, description,
                                    releaseDate, isFavorite));

                            totalProgress += progress;
                        } else {
                            //release reminder
                            //match the date
                            if (date.equals(releaseReminderDate)) {
                                found = true;
                                movieList.add(new Movie(null, null, null, title, null, null,
                                        false));
                            }
                        }
                        i++;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Log.d(MainActivity.TAG, "Query berhasil");
                isProcessFinished = true;
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody,
                                  Throwable error) {
                Log.d(MainActivity.TAG, "Query gagal");
                isProcessFinished = true;
            }

            @Override
            public boolean getUseSynchronousMode() {
                return false;
            }
        });
    }

    //get single movie detail
    private void getSingleFromHTTP(String url, AsyncHttpClient client) {
        client.get(url, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                try {
                    responseObject = new JSONObject(new String(responseBody));

                    double userScore = Double
                            .parseDouble(responseObject
                                    .getString("vote_average")) * 10;
                    int runtime = responseObject.getInt("runtime");

                    String backdrop = responseObject.getString("backdrop_path");
                    String backdropUri = "http://image.tmdb.org/t/p/w780" + backdrop;
                    Bitmap imgBackdrop = null;
                    if (backdrop != null || !backdrop.equals("null")) {
                        Log.d(MainActivity.TAG, "backdrop masuk");
                        imgBackdrop = getPosterBitmap(backdropUri);
                    }

                    movieList.add(new Movie(imgBackdrop, ((int) userScore), runtime));
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Log.d(MainActivity.TAG, "Query berhasil");
                isProcessFinished = true;
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody,
                                  Throwable error) {
                Log.d(MainActivity.TAG, "Query gagal");
                isProcessFinished = true;
            }

            @Override
            public boolean getUseSynchronousMode() {
                return false;
            }
        });

    }

    //for favorite
    public void getMovieFromDatabase() {
        movieList = new ArrayList<>();
        Log.d(MainActivity.TAG, "Sedang mengambil dari database");
        Cursor cursor = context.getContentResolver().query(
                DatabaseContract.CONTENT_URI,
                null,
                null,
                null,
                null
        );

        if (cursor != null) {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                String poster =
                        cursor.getString(cursor.getColumnIndex(DatabaseContract.FavColumns.POSTER_URI));
                Bitmap posterBitmap = getPosterBitmap(POSTER_URI + poster);
                if(posterBitmap == null){
                    posterBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.ic_local_movies_black_24dp);
                }
                String title =
                        cursor.getString(cursor.getColumnIndex(DatabaseContract.FavColumns.TITLE));
                if (urlType == GetMovie.FAVORITE) {
                    String id =
                            cursor.getString(cursor.getColumnIndex(DatabaseContract.FavColumns.MOVIE_ID));
                    Log.d(MainActivity.TAG, "sedang mengambil data: " + title);
                    String desc =
                            cursor.getString(cursor.getColumnIndex(DatabaseContract.FavColumns.DESC));
                    String date =
                            cursor.getString(cursor.getColumnIndex(DatabaseContract.FavColumns.DATE));
                    movieList.add(new Movie(id, poster, posterBitmap, title, desc, date, true));
                } else {
                    movieList.add(new Movie(null, poster, posterBitmap, title, null, null, true));
                }
                cursor.moveToNext();
            }
            cursor.close();
        }
        isProcessFinished = true;
    }

    private String getDateFormatted(String date) {
        String formatted = "";
        try {
            formatted = new SimpleDateFormat
                    ("EEEE, MMM dd, YYYY", Locale.getDefault())
                    .format(new SimpleDateFormat
                            ("yyyy-mm-dd", Locale.getDefault())
                            .parse(date));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return formatted;
    }

    //notify progress into thread
    public double getTotalProgress() {
        return totalProgress;
    }

    public static Bitmap getPosterBitmap(String image) {
        Bitmap bitmap = null;
        try {
            URL url = new URL(image);
            bitmap = BitmapFactory.decodeStream(url.openConnection().getInputStream());

        } catch (Exception e) {
            e.printStackTrace();
        }
        return bitmap;
    }

    private String getUrl(String identifier) {
        String url = "";
        switch (urlType) {
            case UPCOMING: //upcoming
                url = "https://api.themoviedb.org/3/movie/upcoming?api_key=" + API_KEY +
                        "&language=en-US";
                break;
            case SEARCH_RESULT: //search result
                url = "https://api.themoviedb.org/3/search/movie?api_key=" +
                        API_KEY + "&language=en-US&query=" + identifier;
                break;
            case MOVIE_DETAIL: //movie detail
                url = "https://api.themoviedb.org/3/movie/" + identifier +
                        "?api_key=" + API_KEY + "&language=en-US";
                isMovieDetail = true;
                break;
            default: //now showing
                url = "https://api.themoviedb.org/3/movie/now_playing?api_key=" + API_KEY +
                        "&language=en-US";
                break;
        }
        return url;
    }
}
