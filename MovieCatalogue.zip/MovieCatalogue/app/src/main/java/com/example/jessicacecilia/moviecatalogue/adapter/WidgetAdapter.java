package com.example.jessicacecilia.moviecatalogue.adapter;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;


import com.example.jessicacecilia.moviecatalogue.MainActivity;
import com.example.jessicacecilia.moviecatalogue.R;
import com.example.jessicacecilia.moviecatalogue.entity.Movie;
import com.example.jessicacecilia.moviecatalogue.model.AsyncTaskNetwork;
import com.example.jessicacecilia.moviecatalogue.model.GetMovie;
import com.example.jessicacecilia.moviecatalogue.view.MovieViewModel;

import java.util.ArrayList;
import java.util.List;

public class WidgetAdapter implements RemoteViewsService.RemoteViewsFactory {
    private Context context;
    int appWidgetId;
    private boolean hasResult;
    private List<Movie> movies = new ArrayList<>();

    public WidgetAdapter(Context context, Intent intent) {
        this.context = context;
        appWidgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,
                AppWidgetManager.INVALID_APPWIDGET_ID);
    }

    @Override
    public void onCreate() {
        Log.d(MainActivity.TAG, "widget adapter on create");
    }

    @Override
    public void onDataSetChanged() {
        Log.d(MainActivity.TAG, "widget on data set changed");
        hasResult = false;
        new AsyncTaskNetwork(MovieViewModel.createBundle(GetMovie.WIDGET,""),this, context).execute();
        while (!hasResult) {
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void setWidgetData(ArrayList<Movie> movies) {
        Log.d(MainActivity.TAG, "widget pengisian data");
        this.movies.addAll(movies);
        hasResult = true;
    }

    @Override
    public void onDestroy() {

    }

    @Override
    public int getCount() {
        if (movies != null) {
            return movies.size();
        } else {
            return 0;
        }
    }

    //similar to viewholder in adapter
    @Override
    public RemoteViews getViewAt(int i) {
        Log.d(MainActivity.TAG, "widget get view at");

        //on loaded data
        RemoteViews remoteViews = new RemoteViews(context.getPackageName(),
                R.layout.widget_item);
        remoteViews.setImageViewBitmap(R.id.img_widget, movies.get(i).getPoster());
        remoteViews.setTextViewText(R.id.tv_title_widget, movies.get(i).getTitle());
        return remoteViews;
    }

    @Override
    public RemoteViews getLoadingView() {
        return null;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }
}
