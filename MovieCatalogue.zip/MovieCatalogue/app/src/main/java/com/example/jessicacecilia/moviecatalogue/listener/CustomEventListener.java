package com.example.jessicacecilia.moviecatalogue.listener;

import android.app.Activity;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.example.jessicacecilia.moviecatalogue.MainActivity;
import com.example.jessicacecilia.moviecatalogue.R;
import com.example.jessicacecilia.moviecatalogue.database.DatabaseContract;
import com.example.jessicacecilia.moviecatalogue.database.QueryHelper;
import com.example.jessicacecilia.moviecatalogue.entity.Movie;
import com.example.jessicacecilia.moviecatalogue.view.ViewCreatorUtilities;

public class CustomEventListener {
    private final RecyclerView recyclerView;
    private ClickListener clickListener;

    private View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if (clickListener != null) {
                RecyclerView.ViewHolder holder = recyclerView.getChildViewHolder(view);
                clickListener.onClickedAdapter(view, holder.getAdapterPosition(), recyclerView);
            }
        }
    };

    private CustomEventListener(RecyclerView recyclerView) {
        this.recyclerView = recyclerView;
        recyclerView.setTag(R.id.event_listener, this);
        recyclerView.addOnChildAttachStateChangeListener(new RecyclerView.OnChildAttachStateChangeListener() {
            @Override
            public void onChildViewAttachedToWindow(@NonNull View view) {
                if (clickListener != null) {
                    view.setOnClickListener(onClickListener);
                }
            }

            @Override
            public void onChildViewDetachedFromWindow(@NonNull View view) {
            }
        });
    }

    private static CustomEventListener addTo(RecyclerView view) {
        CustomEventListener eventListener = (CustomEventListener) view.getTag(R.id.event_listener);
        if (eventListener == null) {
            eventListener = new CustomEventListener(view);
        }
        return eventListener;
    }

    //only call this function to make listener
    public static void makeAdapterListener(RecyclerView recyclerView, ClickListener listener) {
        CustomEventListener eventListener = addTo(recyclerView);
        eventListener.clickListener = listener;
    }


    //only call this to make fav listener
    public static void setOnClickFavoriteListener(
            Movie movie,
            ImageView imgFav,
            int resBookmark,
            MainActivity activity,
            View view
    ) {
        boolean isFavorite = !movie.isFavorite();
        movie.setFavorite(isFavorite);
        ViewCreatorUtilities.setFavIcon(isFavorite, imgFav, resBookmark);

        CustomEventListener.onClickFavoriteDatabase(
                movie,
                activity
        );
    }

    public static void onClickFavoriteDatabase(Movie movie,
                                               Activity activity) {
        Uri uri = Uri.parse(DatabaseContract.CONTENT_URI + "/" + movie.getId());
        if (!movie.isFavorite()) {
            Log.d(MainActivity.TAG, "fav deleted");
            activity.getContentResolver().delete(
                    uri,
                    null,
                    null
            );
        } else {
            Log.d(MainActivity.TAG, "fav inserted");
            activity.getContentResolver().insert(
                    Uri.parse(DatabaseContract.CONTENT_URI + "/" + movie.getId()),
                    QueryHelper.contentValuesBuilder(movie));
        }
    }
}
