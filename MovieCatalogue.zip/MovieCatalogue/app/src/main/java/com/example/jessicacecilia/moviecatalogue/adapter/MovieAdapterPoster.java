package com.example.jessicacecilia.moviecatalogue.adapter;

import android.graphics.Bitmap;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.jessicacecilia.moviecatalogue.MainActivity;
import com.example.jessicacecilia.moviecatalogue.R;
import com.example.jessicacecilia.moviecatalogue.entity.Movie;
import com.example.jessicacecilia.moviecatalogue.listener.CustomEventListener;
import com.example.jessicacecilia.moviecatalogue.model.GetMovie;
import com.example.jessicacecilia.moviecatalogue.view.ViewCreatorUtilities;

import java.util.ArrayList;

public class MovieAdapterPoster extends RecyclerView.Adapter<MovieAdapterPoster.MovieViewHolder> {
    private ArrayList<Movie> movieList;
    private MainActivity activity;
    private int fragment;

    public MovieAdapterPoster(ArrayList<Movie> movieList,
                              MainActivity activity,
                              int fragment) {
        this.movieList = movieList;
        this.activity = activity;
        this.fragment = fragment;
    }

    @NonNull
    @Override
    public MovieViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.movie_item_grid,
                viewGroup, false);
        Log.d(MainActivity.TAG, "grid adapter on create viewholder");
        return new MovieViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MovieViewHolder movieViewHolder, int i) {
        Movie movie = movieList.get(i);

        movieViewHolder.tvTitle.setText(movie.getTitle());
        Log.d(MainActivity.TAG, "title: " + movie.getTitle());

        Bitmap poster = movie.getPoster();

        if (poster != null) {
            movieViewHolder.imgPoster.setImageBitmap(poster);
        } else {
            movieViewHolder.imgPoster.setImageResource(R.drawable.ic_local_movies_black_24dp);
        }

        ViewCreatorUtilities.setFavIcon(movie.isFavorite(), movieViewHolder.imgFav,
                R.drawable.ic_bookmark);
        Log.d(MainActivity.TAG, movie.getTitle() + " favorite " + movie.isFavorite());

        movieViewHolder.imgFav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CustomEventListener.setOnClickFavoriteListener(
                        movie,
                        movieViewHolder.imgFav,
                        R.drawable.ic_bookmark,
                        activity,
                        view
                );
                activity.viewModel.refreshData(fragment, movieList);
                if (fragment == GetMovie.FAVORITE) {
                    removeItem(movie);
                    Snackbar.make(view, R.string.delete_fav, Snackbar.LENGTH_SHORT)
                            .setAction(R.string.undo_delete_fav,
                                    new View.OnClickListener() {
                                        @Override
                                        public void onClick(View view) {
                                            addItem(movie);
                                            movie.setFavorite(true);
                                            CustomEventListener.onClickFavoriteDatabase(movie,
                                                    activity);
                                        }
                                    })
                            .show();
                } else {
                    int favStat = (movie.isFavorite()) ?
                            R.string.add_fav : R.string.delete_fav;
                    Snackbar.make(view, favStat, Snackbar.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return (movieList == null) ? 0 : movieList.size();
    }

    private void addItem(Movie movie) {
        movieList.add(movie);
        notifyDataSetChanged();
    }

    private void removeItem(Movie movie) {
        movieList.remove(movie);
        notifyDataSetChanged();
    }


    //viewholder which control display
    public static class MovieViewHolder extends RecyclerView.ViewHolder {
        public TextView tvTitle;
        public ImageView imgPoster;
        public ImageView imgFav;

        private MovieViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tv_title_grid);
            imgPoster = itemView.findViewById(R.id.img_poster_grid);
            imgFav = itemView.findViewById(R.id.btn_fav_grid);
        }
    }
}
