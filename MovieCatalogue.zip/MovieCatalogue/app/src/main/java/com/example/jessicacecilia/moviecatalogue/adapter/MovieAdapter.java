package com.example.jessicacecilia.moviecatalogue.adapter;

import android.graphics.Bitmap;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.jessicacecilia.moviecatalogue.MainActivity;
import com.example.jessicacecilia.moviecatalogue.R;
import com.example.jessicacecilia.moviecatalogue.entity.Movie;
import com.example.jessicacecilia.moviecatalogue.listener.CustomEventListener;
import com.example.jessicacecilia.moviecatalogue.view.ViewCreatorUtilities;

import java.util.ArrayList;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.MovieViewHolder> {
    private ArrayList<Movie> movieList;
    private MainActivity activity;
    private int fragment;

    public MovieAdapter(ArrayList<Movie> movieList,
                        MainActivity activity,
                        int fragment) {
        this.movieList = movieList;
        this.activity = activity;
        this.fragment = fragment;
    }

    @NonNull
    @Override
    public MovieViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.movie_item,
                viewGroup, false);
        return new MovieViewHolder(view);
    }

    public void addItem(ArrayList<Movie> movieList) {
        this.movieList = movieList;
        notifyDataSetChanged();
    }

    @Override
    public void onBindViewHolder(@NonNull MovieViewHolder movieViewHolder, int i) {
        Movie movie = movieList.get(i);

        movieViewHolder.tvTitle.setText(movie.getTitle());
        movieViewHolder.tvDesc.setText(cutDescription(movie.getDescription()));
        movieViewHolder.tvDate.setText(movie.getReleaseDate());

        Bitmap poster = movie.getPoster();

        if (poster != null) {
            movieViewHolder.imgPoster.setImageBitmap(poster);
        } else {
            movieViewHolder.imgPoster.setImageResource(R.drawable.ic_local_movies_black_24dp);
        }

        ViewCreatorUtilities.setFavIcon(movie.isFavorite(), movieViewHolder.imgFav,
                R.drawable.ic_bookmark);

        movieViewHolder.imgFav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CustomEventListener.setOnClickFavoriteListener(
                        movie,
                        movieViewHolder.imgFav,
                        R.drawable.ic_bookmark,
                        activity,
                        view
                );
            }
        });
    }


    @Override
    public int getItemCount() {
        return movieList.size();
    }

    private void removeItem(Movie movie) {
        movieList.remove(movie);
        notifyDataSetChanged();
    }

    private void addItem(Movie movie) {
        movieList.add(movie);
        notifyDataSetChanged();
    }

    private String cutDescription(String description) { //cut movie description
        return (description.length() > 30) ? (description.substring(0, 30) + "...") : description;
    }

    //viewholder which control display
    public static class MovieViewHolder extends RecyclerView.ViewHolder {
        public TextView tvTitle;
        public TextView tvDesc;
        public TextView tvDate;
        public ImageView imgPoster;
        public ImageView imgFav;

        private MovieViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvDesc = itemView.findViewById(R.id.tv_desc);
            tvDate = itemView.findViewById(R.id.tv_date);
            imgPoster = itemView.findViewById(R.id.img_poster);
            imgFav = itemView.findViewById(R.id.btn_fav);
        }
    }
}
