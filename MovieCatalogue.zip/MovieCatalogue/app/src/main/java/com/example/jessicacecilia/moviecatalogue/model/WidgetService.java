package com.example.jessicacecilia.moviecatalogue.model;

import android.content.Intent;
import android.util.Log;
import android.widget.RemoteViewsService;

import com.example.jessicacecilia.moviecatalogue.MainActivity;
import com.example.jessicacecilia.moviecatalogue.adapter.WidgetAdapter;

public class WidgetService extends RemoteViewsService {
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        Log.d(MainActivity.TAG, "widget on get view factory");
        return new WidgetAdapter(this.getApplicationContext(), intent);
    }
}
