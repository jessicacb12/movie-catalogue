package com.example.jessicacecilia.moviecatalogue;

import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.example.jessicacecilia.moviecatalogue.view.MovieViewModel;
import com.example.jessicacecilia.moviecatalogue.view.TabCreator;
import com.example.jessicacecilia.moviecatalogue.view.ViewCreatorUtilities;
import com.example.jessicacecilia.moviecatalogue.view.ViewPagerAdapter;

public class MainActivity extends AppCompatActivity {
    public SwipeRefreshLayout refreshLayout;

    public TabLayout tabs;
    public ViewPager viewPager;
    public ViewPagerAdapter viewPagerAdapter;

    public int currentFragment = -1;
    public static final String TAG = "tag";
    public MovieViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //setting up tabs
        viewPager = findViewById(R.id.pager);
        viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        tabs = findViewById(R.id.home_tabs);
        new TabCreator(this).generate();

        refreshLayout = findViewById(R.id.layout_swipe_refresh);
        refreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                ViewCreatorUtilities.refreshData(MainActivity.this,
                        tabs.getSelectedTabPosition());
            }
        });

        viewModel = ViewModelProviders.of(this).get(MovieViewModel.class);
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(MainActivity.TAG, "Main activity pause");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(MainActivity.TAG, "Main activity resume");

    }
}
