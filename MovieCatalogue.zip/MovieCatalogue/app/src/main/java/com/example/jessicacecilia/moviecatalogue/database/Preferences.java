package com.example.jessicacecilia.moviecatalogue.database;

import android.content.Context;
import android.content.SharedPreferences;

public class Preferences {

    private String KEY_DAILY = "key_daily";
    private String KEY_RELEASE = "key_release";
    private SharedPreferences preferences;

    public Preferences(Context context) {
        String PREFS_NAME = "UserPref";
        preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public void setDaily(int daily) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(KEY_DAILY, daily);
        editor.apply();
    }

    public int getDaily() {
        return preferences.getInt(KEY_DAILY, 0);
    }

    public void setRelease(int release) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(KEY_RELEASE, release);
        editor.apply();
    }

    public int getRelease() {
        return preferences.getInt(KEY_RELEASE, 0);
    }

}
