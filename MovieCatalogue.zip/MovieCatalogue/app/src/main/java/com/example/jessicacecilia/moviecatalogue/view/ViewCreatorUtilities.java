package com.example.jessicacecilia.moviecatalogue.view;

import android.os.Handler;
import android.widget.ImageView;

import com.example.jessicacecilia.moviecatalogue.MainActivity;
import com.example.jessicacecilia.moviecatalogue.R;


public class ViewCreatorUtilities {

    //function to change fav icon
    public static void setFavIcon(boolean isFavorite, ImageView favIcon, int resBookmark) {
        if (isFavorite) {
            favIcon.setImageResource(R.drawable.ic_bookmarked);
        } else {
            favIcon.setImageResource(resBookmark);
        }
    }

    //function to refresh data when swipe refresh listener is called
    public static void refreshData(MainActivity activity, int tabPosition) {
        new Handler().post(new Runnable() {
            @Override
            public void run() {
                switch (tabPosition) {
                    case TabCreator.TAB_HOME:
                        activity
                                .viewModel
                                .refreshHomeData();
                        break;
                    case TabCreator.TAB_FAV:
                        activity
                                .viewModel
                                .refreshDataFav();
                        break;
                }
                activity.refreshLayout.setRefreshing(false);
            }
        });

    }
}