package com.example.jessicacecilia.moviecatalogue;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.jessicacecilia.moviecatalogue.adapter.AdapterListener;
import com.example.jessicacecilia.moviecatalogue.adapter.MovieAdapter;
import com.example.jessicacecilia.moviecatalogue.entity.Movie;
import com.example.jessicacecilia.moviecatalogue.model.GetMovie;

import java.util.ArrayList;

public class SearchResultFragment extends Fragment {
    private TextView tvNoConnection;
    public RecyclerView rvMovie;
    public ProgressBar progressBar;
    public TextView tvProgress;
    public EditText edtSearch;
    private MainActivity activity;

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        Log.d(MainActivity.TAG, "Fragment Creation");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_search_result, container, false);
        activity = (MainActivity) getActivity();
        activity.viewModel.setSearchResultFragment(this);

        tvNoConnection = view.findViewById(R.id.tv_no_connection);
        rvMovie = view.findViewById(R.id.rv_movie);
        rvMovie.setLayoutManager(new LinearLayoutManager(this.getContext()));
        tvProgress = view.findViewById(R.id.tv_progress);
        progressBar = view.findViewById(R.id.progress_bar);
        progressBar.setMax(100);

        //progress bar and no conn notif are set up invincible at first

        progressBar.setVisibility(View.INVISIBLE);
        tvProgress.setVisibility(View.INVISIBLE);
        tryToConnect();
        edtSearch = view.findViewById(R.id.edt_search);

        //load loaded data
        if (activity.viewModel.getSearchTitle() != null) {
            activity.viewModel.getDataSearch(activity.viewModel.getSearchTitle());
        }

        //on click search
        edtSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int event, KeyEvent keyEvent) {
                if (event == EditorInfo.IME_ACTION_SEARCH) {
                    String search = edtSearch.getText().toString();
                    if (!search.isEmpty()) {
                        //start search
                        tvNoConnection.setVisibility(View.INVISIBLE);
                        activity.viewModel.getDataSearch(search);
                    }
                }
                return true;
            }
        });

        return view;
    }

    public void setAdapter(ArrayList<Movie> movies) {
        rvMovie.setAdapter(new MovieAdapter(movies, activity, GetMovie.SEARCH_RESULT));
        AdapterListener.toMovieDetail(rvMovie, movies, activity);
    }

    public void setProgressVisible() {
        progressBar.setVisibility(View.VISIBLE);
        tvProgress.setVisibility(View.VISIBLE);
    }

    public void setProgressInvinsible() {
        progressBar.setVisibility(View.INVISIBLE);
        tvProgress.setVisibility(View.INVISIBLE);
    }

    public void setProgress(int progress) {
        progress += progressBar.getProgress();
        progressBar.setProgress(progress);
        tvProgress.setText(
                String.format(
                        getResources()
                                .getString(R.string.progress), progress)
        );

        if (progressBar.getProgress() == 100) {
            setProgressInvinsible();
        }
    }

    public void tryToConnect() {
        tvNoConnection.setVisibility(View.INVISIBLE);
    }

    public void setNoConnection() {
        tvNoConnection.setVisibility(View.VISIBLE);
    }
}



