package com.example.jessicacecilia.moviecatalogue.entity;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.Parcelable;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class Movie implements Parcelable {
    private String id;
    private Bitmap poster;
    private String posterUri;
    private String title;
    private String description;
    private String releaseDate;
    private Bitmap backdrop;
    private int userScore;
    private int runtime;
    private boolean isFavorite;


    public Movie(String id,
                 String posterUri,
                 Bitmap poster,
                 String title,
                 String description,
                 String releaseDate,
                 boolean isFavorite) {
        this.id = id;
        this.poster = poster;
        this.posterUri = posterUri;
        this.title = title;
        this.description = description;
        this.releaseDate = releaseDate;
        this.isFavorite = isFavorite;
    }

    //constructor for additional info
    public Movie(Bitmap backdrop, int userScore, int runtime) {
        this.backdrop = backdrop;
        this.userScore = userScore;
        this.runtime = runtime;
    }


    protected Movie(Parcel in) {
        id = in.readString();
        poster = in.readParcelable(Bitmap.class.getClassLoader());
        posterUri = in.readString();
        title = in.readString();
        description = in.readString();
        releaseDate = in.readString();
        backdrop = in.readParcelable(Bitmap.class.getClassLoader());
        userScore = in.readInt();
        runtime = in.readInt();
        isFavorite = in.readByte() != 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeParcelable(poster, flags);
        dest.writeString(posterUri);
        dest.writeString(title);
        dest.writeString(description);
        dest.writeString(releaseDate);
        dest.writeParcelable(backdrop, flags);
        dest.writeInt(userScore);
        dest.writeInt(runtime);
        dest.writeByte((byte) (isFavorite ? 1 : 0));
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Movie> CREATOR = new Creator<Movie>() {
        @Override
        public Movie createFromParcel(Parcel in) {
            return new Movie(in);
        }

        @Override
        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };

    public void setFavorite(boolean favorite) {
        isFavorite = favorite;
    }

    public boolean isFavorite() {
        return isFavorite;
    }

    public String getId() {
        return id;
    }

    public Bitmap getBackdrop() {
        return backdrop;
    }

    public int getUserScore() {
        return userScore;
    }

    public Bitmap getPoster() {
        return poster;
    }

    public String getPosterUri() {
        return posterUri;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public int getRuntime() {
        return runtime;
    }

    public String getYear() {
        String year = null;
        try {
            year = new SimpleDateFormat("YYYY", Locale.getDefault()).format(
                    new SimpleDateFormat("EEEE, MMM dd, YYYY", Locale.getDefault()).parse(releaseDate));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return year;
    }

}
