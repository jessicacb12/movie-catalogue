package com.example.jessicacecilia.moviecatalogue.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    public DatabaseHelper(Context context) {
        super(context,
                DatabaseContract.DBNAME,
                null,
                DatabaseContract.DBVERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query =
                "CREATE TABLE " + DatabaseContract.TABLENAME + "(" +
                        DatabaseContract.FavColumns._ID + " INTEGER," +
                        DatabaseContract.FavColumns.MOVIE_ID + " TEXT PRIMARY KEY NOT NULL," +
                        DatabaseContract.FavColumns.TITLE + " TEXT NOT NULL," +
                        DatabaseContract.FavColumns.DESC + " TEXT NOT NULL," +
                        DatabaseContract.FavColumns.DATE + " TEXT NOT NULL," +
                        DatabaseContract.FavColumns.POSTER_URI + " TEXT NOT NULL);";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + DatabaseContract.TABLENAME);
        onCreate(db);
    }
}
