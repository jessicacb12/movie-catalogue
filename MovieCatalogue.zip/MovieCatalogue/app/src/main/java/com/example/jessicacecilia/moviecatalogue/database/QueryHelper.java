package com.example.jessicacecilia.moviecatalogue.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.jessicacecilia.moviecatalogue.MainActivity;
import com.example.jessicacecilia.moviecatalogue.entity.Movie;

public class QueryHelper {
    private Context context;
    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    public QueryHelper(Context context) {
        this.context = context;
    }

    public QueryHelper open() throws SQLException {
        dbHelper = new DatabaseHelper(context);
        db = dbHelper.getWritableDatabase();
        return this;
    }

    //every queries which will be done will use ID

    //to display all favorites
    public Cursor query() {
        return db.query(DatabaseContract.TABLENAME,
                null,
                null,
                null,
                null,
                null,
                DatabaseContract.FavColumns._ID + " DESC");
        //movies should be displayed in stack
    }

    public Cursor queryById(String id) {
        return db.query(DatabaseContract.TABLENAME, null
                , DatabaseContract.FavColumns.MOVIE_ID + " = ?"
                , new String[]{id}
                , null
                , null
                , null
                , null);
    }

    //to add movie into favorites
    public long insert(ContentValues cv) {
        Log.d(MainActivity.TAG, "masuk insert provider");
        return db.insert(DatabaseContract.TABLENAME,
                null,
                cv);
    }

    //to delete from fav list based on id provided
    public int delete(String id) {
        return db.delete(DatabaseContract.TABLENAME,
                DatabaseContract.FavColumns.MOVIE_ID
                        + " = ?",
                new String[]{id});
    }

    public static ContentValues contentValuesBuilder(Movie movie) {
        ContentValues cv = new ContentValues();
        cv.put(DatabaseContract.FavColumns.MOVIE_ID, movie.getId());
        cv.put(DatabaseContract.FavColumns.TITLE, movie.getTitle());
        cv.put(DatabaseContract.FavColumns.DESC, movie.getDescription());
        cv.put(DatabaseContract.FavColumns.DATE, movie.getReleaseDate());
        cv.put(DatabaseContract.FavColumns.POSTER_URI, movie.getPosterUri());

        Log.d(MainActivity.TAG, "cv build: " + movie.getPosterUri());
        return cv;
    }

    public void close() {
        db.close();
    }
}
