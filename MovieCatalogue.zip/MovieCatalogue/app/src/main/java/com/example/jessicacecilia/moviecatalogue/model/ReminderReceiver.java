package com.example.jessicacecilia.moviecatalogue.model;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.example.jessicacecilia.moviecatalogue.MainActivity;
import com.example.jessicacecilia.moviecatalogue.R;
import com.example.jessicacecilia.moviecatalogue.view.MovieViewModel;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;


public class ReminderReceiver extends BroadcastReceiver {
    private static final String EXTRA_ID = "id";
    private static final String EXTRA_CONTENT = "content";

    public static final int DAILY = 80;
    public static final int RELEASE = 81;

    private Context tempContext;

    @Override
    public void onReceive(Context context, Intent intent) {
        int reminderId = intent.getIntExtra(EXTRA_ID, 0);
        Log.d(MainActivity.TAG, "on receive " + reminderId);
        String content = intent.getStringExtra(EXTRA_CONTENT);

        String title = context.getString(R.string.daily_reminder_title);

        if (reminderId == DAILY) {
            showNotification(context, reminderId, title, content);
        } else {
            //check release, then show notif if necessary
            tempContext = context;
            DateFormat rawDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            new AsyncTaskNetwork(
                    MovieViewModel
                            .createBundle(GetMovie.RELEASE_REMINDER,
                                    "2018-12-15"),
                    this).execute();
//            viewModel.loadData(GetMovie.RELEASE_REMINDER,rawDate.format(new Date()));
        }
    }

    public void acknowledgeRelease(String movieTitle) {
        showNotification(
                tempContext,
                RELEASE,
                tempContext.getString(R.string.release_reminder_title),
                tempContext
                        .getString(
                                R.string.release_reminder_content,
                                movieTitle)
        );
    }

    private void showNotification(Context context, int id, String title, String content) {
        String CHANNEL = "Channel_1";
        String CHANNEL_NAME = "ReelzReminder Channel";

        //on click open app
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, 0);


        NotificationManager manager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationCompat.Builder notifBuilder = new NotificationCompat.Builder(context, CHANNEL)
                .setContentIntent(pendingIntent)
                .setContentTitle(title)
                .setContentText(content)
                .setSmallIcon(R.drawable.movie_icon)
                .setLargeIcon(
                        BitmapFactory
                                .decodeResource(
                                        context.getResources(),
                                        R.drawable.movie_icon
                                )
                )
                .setVibrate(new long[]{1000, 1000, 1000, 1000})
                .setAutoCancel(true);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel =
                    new NotificationChannel(CHANNEL,
                            CHANNEL_NAME,
                            NotificationManager.IMPORTANCE_DEFAULT);
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{1000, 1000, 1000, 1000});
            notifBuilder.setChannelId(CHANNEL);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
        Notification notif = notifBuilder.build();
        if (manager != null) {
            manager.notify(id, notif);
        }
    }

    public void setReminder(Context context, int id, String time, String content) {

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.putExtra(EXTRA_CONTENT, content);
        intent.putExtra(EXTRA_ID, id);

        String timeArray[] = time.split(":");
        Log.d(MainActivity.TAG, id + " set time on " + timeArray[0] + timeArray[1]);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());

        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, id, intent, 0);

        if (alarmManager != null) {
            alarmManager.setRepeating(
                    AlarmManager.RTC,
                    calendar.getTimeInMillis(),
                    24 * 60 * 60 * 1000,
                    pendingIntent);
        }
    }

    public void cancelReminder(Context context, int id) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, ReminderReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, id, intent, 0);
        pendingIntent.cancel();

        if (manager != null) {
            manager.cancel(pendingIntent);
        }
    }
}
