package com.example.jessicacecilia.moviecatalogue.view;

import android.support.design.widget.TabLayout;

import com.example.jessicacecilia.moviecatalogue.FavoriteFragment;
import com.example.jessicacecilia.moviecatalogue.HomeFragment;
import com.example.jessicacecilia.moviecatalogue.MainActivity;
import com.example.jessicacecilia.moviecatalogue.R;
import com.example.jessicacecilia.moviecatalogue.SearchResultFragment;
import com.example.jessicacecilia.moviecatalogue.SettingFragment;


public class TabCreator {
    private MainActivity activity;

    //tab type
    public static final int TAB_HOME = 0;
    public static final int TAB_SEARCH = 1;
    public static final int TAB_FAV = 2;
    public static final int TAB_SETTING = 3;

    public TabCreator(MainActivity activity) {
        this.activity = activity;
    }

    public void generate() {
        //populating tab
        activity.viewPagerAdapter.addFragment(
                activity
                        .getResources()
                        .getString(R.string.home),
                new HomeFragment()
        );
        activity.viewPagerAdapter.addFragment(
                activity
                        .getResources()
                        .getString(R.string.search),
                new SearchResultFragment()
        );
        activity.viewPagerAdapter.addFragment(
                activity
                        .getResources()
                        .getString(R.string.fav),
                new FavoriteFragment()
        );
        activity.viewPagerAdapter.addFragment(
                activity
                        .getResources()
                        .getString(R.string.setting),
                new SettingFragment()
        );

        activity.viewPager.setAdapter(activity.viewPagerAdapter);
        activity.tabs.setupWithViewPager(activity.viewPager);
        setTabIcon();
    }

    private void setTabIcon() {
        setTabWithIcon(TAB_HOME, R.drawable.ic_tab_home_active);
        setTabWithIcon(TAB_SEARCH, R.drawable.ic_search_24dp);
        setTabWithIcon(TAB_FAV, R.drawable.ic_bookmark);
        setTabWithIcon(TAB_SETTING, R.drawable.ic_tab_setting);

        activity.tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                switch (tab.getPosition()) {
                    case TAB_HOME:
                        setTabWithIcon(TAB_HOME, R.drawable.ic_tab_home_active);
                        break;
                    case TAB_SEARCH:
                        setTabWithIcon(TAB_SEARCH, R.drawable.ic_tab_search_active);
                        break;
                    case TAB_FAV:
                        setTabWithIcon(TAB_FAV, R.drawable.ic_tab_fav_active);
                        break;
                    case TAB_SETTING:
                        setTabWithIcon(TAB_SETTING, R.drawable.ic_tab_setting_active);
                        break;
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                switch (tab.getPosition()) {
                    case TAB_HOME:
                        setTabWithIcon(TAB_HOME, R.drawable.ic_tab_home);
                        break;
                    case TAB_SEARCH:
                        setTabWithIcon(TAB_SEARCH, R.drawable.ic_search_24dp);
                        break;
                    case TAB_FAV:
                        setTabWithIcon(TAB_FAV, R.drawable.ic_bookmark);
                        break;
                    case TAB_SETTING:
                        setTabWithIcon(TAB_SETTING, R.drawable.ic_tab_setting);
                        break;
                }
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }

    private void setTabWithIcon(int tabPosition, int resIcon) {
        activity
                .tabs
                .getTabAt(tabPosition)
                .setIcon(resIcon);
    }
}
