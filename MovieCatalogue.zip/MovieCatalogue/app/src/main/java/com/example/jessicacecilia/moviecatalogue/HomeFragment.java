package com.example.jessicacecilia.moviecatalogue;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.jessicacecilia.moviecatalogue.adapter.AdapterListener;
import com.example.jessicacecilia.moviecatalogue.adapter.MovieAdapterPoster;
import com.example.jessicacecilia.moviecatalogue.entity.Movie;
import com.example.jessicacecilia.moviecatalogue.model.GetMovie;

import java.util.ArrayList;

public class HomeFragment extends Fragment {
    private ProgressBar progressBar;
    private TextView tvProgress;
    private TextView tvNoConn;
    private TextView tvNowShowing;
    private TextView tvUpcoming;
    public RecyclerView rvNowShowing;
    public RecyclerView rvUpcoming;

    private MainActivity activity;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        Log.d(MainActivity.TAG, "home fragment");
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        activity = (MainActivity) getActivity();
        activity.viewModel.setHomeFragment(this);

        tvNowShowing = view.findViewById(R.id.tv_now_showing);
        tvNowShowing.setVisibility(View.INVISIBLE);
        tvUpcoming = view.findViewById(R.id.tv_upcoming);
        tvUpcoming.setVisibility(View.INVISIBLE);
        tvNoConn = view.findViewById(R.id.tv_no_connection);
        progressBar = view.findViewById(R.id.progress_bar);
        progressBar.setMax(100);
        progressBar.setVisibility(View.INVISIBLE);
        tvProgress = view.findViewById(R.id.tv_progress);
        tvProgress.setVisibility(View.INVISIBLE);

        //recycler view set up
        rvNowShowing = view.findViewById(R.id.rv_now_showing);
        rvNowShowing.setLayoutManager(
                new LinearLayoutManager(
                        getContext(),
                        LinearLayoutManager.HORIZONTAL,
                        false)
        );
        rvNowShowing.setHasFixedSize(true);
        rvUpcoming = view.findViewById(R.id.rv_upcoming);
        rvUpcoming.setLayoutManager(
                new LinearLayoutManager(
                        getContext(),
                        LinearLayoutManager.HORIZONTAL,
                        false)
        );
        rvUpcoming.setHasFixedSize(true);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Log.d(MainActivity.TAG, "pasang adapter");
        setProgress(0);

        activity.viewModel.getNowShowing();
        activity.viewModel.getUpcoming();
        tryToConnect();
    }


    public void setNoConnection() {
        tvNoConn.setVisibility(View.VISIBLE);
    }

    public void tryToConnect() {
        tvNoConn.setVisibility(View.INVISIBLE);
    }

    //setting adapter from viewmodel
    public void setAdapterNowShowing(ArrayList<Movie> movies) {
        rvNowShowing.setAdapter(new MovieAdapterPoster(movies, activity, GetMovie.NOW_SHOWING));
        AdapterListener.toMovieDetail(rvNowShowing, movies, activity);
    }

    public void setAdapterUpcoming(ArrayList<Movie> movies) {
        rvUpcoming.setAdapter(new MovieAdapterPoster(movies, activity, GetMovie.UPCOMING));
        AdapterListener.toMovieDetail(rvUpcoming, movies, activity);
    }

    //progress
    public void setProgressInvinsible() {
        tvNowShowing.setVisibility(View.VISIBLE);
        tvUpcoming.setVisibility(View.VISIBLE);
        progressBar.setVisibility(View.INVISIBLE);
        tvProgress.setVisibility(View.INVISIBLE);
    }

    public void setProgressVisible() {
        tvNowShowing.setVisibility(View.INVISIBLE);
        tvUpcoming.setVisibility(View.INVISIBLE);
        progressBar.setVisibility(View.VISIBLE);
        tvProgress.setVisibility(View.VISIBLE);
    }

    public void setProgress(int progress) {
        progress += progressBar.getProgress();
        progressBar.setProgress(progress);
        tvProgress.setText(
                String.format(
                        getResources()
                                .getString(R.string.progress), progress)
        );

        if (progressBar.getProgress() == 100) {
            setProgressInvinsible();
        }
    }
}
