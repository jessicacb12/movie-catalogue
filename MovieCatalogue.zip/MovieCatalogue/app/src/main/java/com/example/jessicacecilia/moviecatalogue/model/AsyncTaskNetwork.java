package com.example.jessicacecilia.moviecatalogue.model;

import android.arch.lifecycle.MutableLiveData;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.example.jessicacecilia.moviecatalogue.MainActivity;
import com.example.jessicacecilia.moviecatalogue.adapter.WidgetAdapter;
import com.example.jessicacecilia.moviecatalogue.entity.Movie;
import com.example.jessicacecilia.moviecatalogue.view.MovieViewModel;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.ArrayList;

public class AsyncTaskNetwork extends AsyncTask<Void, Integer, ArrayList<Movie>> {
    private Bundle bundle;
    private ReminderReceiver releaseReminderReceiver;
    private MovieViewModel viewModel;

    //widget param
    private WidgetAdapter widgetAdapter;
    private Context context;

    private boolean hasResult;
    private int urlType;
    private GetMovie getMovie;

    public AsyncTaskNetwork(Bundle bundle) {
        this.bundle = bundle;
        hasResult = false;
    }

    //for widget
    public AsyncTaskNetwork(Bundle bundle,WidgetAdapter widgetAdapter, Context context){
        this(bundle);
        this.widgetAdapter = widgetAdapter;
        this.context = context;
    }

    //for reminder
    public AsyncTaskNetwork(Bundle bundle, ReminderReceiver reminderReceiver) {
        this(bundle);
        this.releaseReminderReceiver = reminderReceiver;
    }

    //used mostly
    public AsyncTaskNetwork(Bundle bundle, MovieViewModel viewModel) {
        this(bundle);
        this.viewModel = viewModel;
    }

    @Override
    protected void onPreExecute() {
        Log.d(MainActivity.TAG, "on pre execute");
        super.onPreExecute();
        urlType = bundle.getInt(GetMovie.EXTRA_URL_TYPE);
    }

    @Override
    protected ArrayList<Movie> doInBackground(Void... voids) {
        Log.d(MainActivity.TAG, "Loader sampe di load in background");
        String identifier = bundle.getString(GetMovie.EXTRA_IDENTIFIER);

        if (urlType == GetMovie.WIDGET) {
            getMovie = new GetMovie(context);
            getMovie.getMovieFromDatabase();
        } else if (urlType == GetMovie.FAVORITE) {
            getMovie = new GetMovie(viewModel.getFavoriteFragment().getActivity());
            getMovie.getMovieFromDatabase();
        } else {
            if (urlType == GetMovie.RELEASE_REMINDER) {
                getMovie = new GetMovie();
            } else if (urlType == GetMovie.MOVIE_DETAIL) {
                getMovie = new GetMovie(viewModel.getDetailFragment().getActivity());
            } else if (urlType == GetMovie.SEARCH_RESULT) {
                getMovie = new GetMovie(viewModel.getSearchResultFragment().getActivity());
            } else {
                getMovie = new GetMovie(viewModel.getHomeFragment().getActivity());
            }

            if (isConnected()) {
                Log.d(MainActivity.TAG, "pas awal ada koneksi");
                getMovie.query(urlType, identifier);
            } else {
                Log.d(MainActivity.TAG, "pas awal tidak ada koneksi");
                hasResult = true;
            }
        }

        Log.d(MainActivity.TAG, "Hasil has result: " + hasResult);

        //delay program while hasn't fully loaded movies
        while (!hasResult) {
            hasResult = getMovie.processFinished();
            try {
                Thread.sleep(50);
                if (urlType != GetMovie.MOVIE_DETAIL
                        && urlType != GetMovie.FAVORITE
                        && urlType != GetMovie.RELEASE_REMINDER
                        && urlType != GetMovie.WIDGET) {
                    //keluarin progress bar
                    int progress = (int) getMovie.getTotalProgress();
                    publishProgress(progress);
                    if (!isConnected()) {
                        hasResult = true;
                    }
                    Log.d(MainActivity.TAG, "update progress: " + progress);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }


        return getMovie.getMovieList();
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
        if (urlType == GetMovie.NOW_SHOWING
                || urlType == GetMovie.UPCOMING) {
            viewModel.getHomeFragment().setProgress(values[0]);
        } else {
            viewModel.getSearchResultFragment().setProgress(values[0]);
        }
    }

    @Override
    protected void onPostExecute(ArrayList<Movie> movies) {
        super.onPostExecute(movies);
        Log.d(MainActivity.TAG, "onPost execute");
        if (movies != null && movies.size() > 0) {
            MutableLiveData<ArrayList<Movie>> data = new MutableLiveData<>();
            data.setValue(movies);
            Log.d(MainActivity.TAG, "di live data ada: " + data.getValue().get(0).getTitle());

            switch (urlType) {
                case GetMovie.NOW_SHOWING:
                    viewModel.setNowShowing(data);
                    viewModel.getHomeFragment().setAdapterNowShowing(movies);
                    break;
                case GetMovie.UPCOMING:
                    viewModel.setUpcoming(data);
                    viewModel.getHomeFragment().setAdapterUpcoming(movies);
                    break;
                case GetMovie.SEARCH_RESULT:
                    viewModel.setDataSearch(data);
                    viewModel.getSearchResultFragment().setAdapter(movies);
                    break;
                case GetMovie.MOVIE_DETAIL:
                    viewModel.setMovieDetail(data.getValue().get(0));
                    viewModel.getDetailFragment().setLoadedData(data.getValue().get(0));
                    break;
                case GetMovie.FAVORITE:
                    viewModel.setDataFav(data);
                    viewModel.getFavoriteFragment().setAdapter(movies);
                    break;
                case GetMovie.RELEASE_REMINDER:
                    releaseReminderReceiver.acknowledgeRelease(movies.get(0).getTitle());
                    break;
                case GetMovie.WIDGET:
                    widgetAdapter.setWidgetData(movies);
                    break;
            }
        } else {
            switch (urlType) {
                case GetMovie.NOW_SHOWING:
                    viewModel.getHomeFragment().setProgressInvinsible();
                    viewModel.getHomeFragment().setNoConnection();
                    break;
                case GetMovie.UPCOMING:
                    viewModel.getHomeFragment().setProgressInvinsible();
                    viewModel.getHomeFragment().setNoConnection();
                    break;
                case GetMovie.SEARCH_RESULT:
                    viewModel.getSearchResultFragment().setProgressInvinsible();
                    viewModel.getSearchResultFragment().setNoConnection();
                    break;
                case GetMovie.FAVORITE:
                    viewModel.getFavoriteFragment().tvNoFav.setVisibility(View.VISIBLE);
                    break;
            }
        }
    }


    public boolean isConnected() {
        try {
            int timeoutMs = 1500;
            Socket sock = new Socket();
            SocketAddress sockaddr = new InetSocketAddress("8.8.8.8", 53);

            sock.connect(sockaddr, timeoutMs);
            sock.close();

            return true;
        } catch (IOException e) {
            return false;
        }
    }
}
