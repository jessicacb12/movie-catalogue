package com.example.jessicacecilia.moviecatalogue;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.jessicacecilia.moviecatalogue.adapter.AdapterListener;
import com.example.jessicacecilia.moviecatalogue.adapter.MovieAdapterPoster;
import com.example.jessicacecilia.moviecatalogue.entity.Movie;
import com.example.jessicacecilia.moviecatalogue.model.GetMovie;

import java.util.ArrayList;

public class FavoriteFragment extends Fragment {
    ArrayList<Movie> movies;
    public RecyclerView rvFav;
    public TextView tvNoFav;
    private MainActivity activity;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_favorite, container, false);
        activity = (MainActivity) getActivity();
        activity.viewModel.setFavoriteFragment(this);

        rvFav = view.findViewById(R.id.rv_fav);
        rvFav.setLayoutManager(new GridLayoutManager(this.getContext(), 3));
        tvNoFav = view.findViewById(R.id.tv_no_fav);
        tvNoFav.setVisibility(View.INVISIBLE);

        activity.viewModel.getDataFav();

        return view;
    }

    public void setAdapter(ArrayList<Movie> movies) {
        this.movies = movies;
        rvFav.setAdapter(new MovieAdapterPoster(movies, activity, GetMovie.FAVORITE));
        AdapterListener.toMovieDetail(rvFav, movies, activity);
    }
}
