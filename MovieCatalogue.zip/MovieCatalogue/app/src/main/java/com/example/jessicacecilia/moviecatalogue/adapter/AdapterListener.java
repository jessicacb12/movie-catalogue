package com.example.jessicacecilia.moviecatalogue.adapter;

import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.example.jessicacecilia.moviecatalogue.MainActivity;
import com.example.jessicacecilia.moviecatalogue.MovieDetailFragment;
import com.example.jessicacecilia.moviecatalogue.R;
import com.example.jessicacecilia.moviecatalogue.entity.Movie;
import com.example.jessicacecilia.moviecatalogue.listener.ClickListener;
import com.example.jessicacecilia.moviecatalogue.listener.CustomEventListener;
import com.example.jessicacecilia.moviecatalogue.model.GetMovie;

import java.util.ArrayList;

public class AdapterListener {
    public static final String EXTRA_MOVIE = "movie extra";

    public static void toMovieDetail(
            RecyclerView rv,
            ArrayList<Movie> movies,
            MainActivity activity
    ) {
        CustomEventListener.makeAdapterListener(
                rv,
                new ClickListener() {
                    @Override
                    public void onClickedAdapter(View view, int position,
                                                 RecyclerView recyclerView) {
                        directlyOpenDetail(activity, movies, position);
                    }
                }
        );
    }

    public static void directlyOpenDetail(MainActivity activity,
                                          ArrayList<Movie> movies,
                                          int position) {
        Bundle bundle = new Bundle();
        bundle.putParcelable(EXTRA_MOVIE, movies.get(position));
        MovieDetailFragment detailFragment = new MovieDetailFragment();
        detailFragment.setArguments(bundle);
        activity.currentFragment = GetMovie.MOVIE_DETAIL;
        activity.getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.fragment_container,
                        detailFragment,
                        MovieDetailFragment.class.getSimpleName())
                .addToBackStack(MovieDetailFragment.class.getSimpleName())
                .commit();
    }
}
