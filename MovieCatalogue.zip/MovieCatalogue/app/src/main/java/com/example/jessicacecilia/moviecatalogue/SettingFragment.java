package com.example.jessicacecilia.moviecatalogue;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.jessicacecilia.moviecatalogue.database.Preferences;
import com.example.jessicacecilia.moviecatalogue.model.ReminderReceiver;

public class SettingFragment extends Fragment implements View.OnClickListener {
    private Button btnChangeLang;
    private Button btnDailyReminder;
    private Button btnReleaseReminder;
    private Preferences preferences;

    private ReminderReceiver reminder;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_setting, container, false);
        preferences = new Preferences(this.getActivity().getBaseContext());
        reminder = new ReminderReceiver();

        btnChangeLang = view.findViewById(R.id.btn_change_lang);
        btnChangeLang.setOnClickListener(this);
        btnDailyReminder = view.findViewById(R.id.btn_daily_reminder);
        btnDailyReminder.setText(setButtonText(preferences.getDaily(), R.string.daily_reminder));
        btnDailyReminder.setOnClickListener(this);
        btnReleaseReminder = view.findViewById(R.id.btn_release_reminder);
        btnReleaseReminder.setText(setButtonText(preferences.getRelease(),
                R.string.release_reminder));
        btnReleaseReminder.setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_change_lang:
                Intent intent = new Intent(Settings.ACTION_LOCALE_SETTINGS);
                startActivity(intent);
                break;

            case R.id.btn_daily_reminder:
                int isEnable = preferences.getDaily();
                if (isEnable == 0) {
                    isEnable = 1;
                    reminder.setReminder(
                            this.getActivity().getBaseContext(),
                            ReminderReceiver.DAILY,
                            "07:00",
                            getString(R.string.daily_notif));
                    Snackbar.make(view, getString(R.string.daily_snackbar),
                            Snackbar.LENGTH_SHORT).show();
                } else {
                    reminder.cancelReminder(this.getActivity().getBaseContext(),
                            ReminderReceiver.DAILY);
                    isEnable = 0;
                }
                preferences.setDaily(isEnable);
                btnDailyReminder.setText(setButtonText(isEnable, R.string.daily_reminder));
                break;
            case R.id.btn_release_reminder:
                isEnable = preferences.getRelease();
                if (isEnable == 0) {
                    isEnable = 1;
                    reminder.setReminder(
                            this.getActivity().getBaseContext(),
                            ReminderReceiver.RELEASE,
                            "08:00",
                            ""); //content is intentionally left blank
                    Snackbar.make(view, R.string.release_snackbar, Snackbar.LENGTH_LONG).show();
                } else {
                    reminder.cancelReminder(this.getActivity().getBaseContext(),
                            ReminderReceiver.RELEASE);
                    isEnable = 0;
                }
                preferences.setRelease(isEnable);
                btnReleaseReminder.setText(setButtonText(isEnable, R.string.release_reminder));
                break;
        }
    }

    private String setButtonText(int isOn, int resText) {
        String isEnable =
                (isOn == 0) ?
                        getResources().getString(R.string.enable) :
                        getResources().getString(R.string.disable);

        return getResources().getString(resText, isEnable);
    }


}
