package com.example.jessicacecilia.moviecatalogue.database;

import android.database.Cursor;
import android.net.Uri;
import android.provider.BaseColumns;

public class DatabaseContract {
    public static final String DBNAME = "db_watchlist";
    public static final int DBVERSION = 2;
    public static final String TABLENAME = "favorite";
    public static final String AUTHORITY = "com.example.jessicacecilia.moviecatalogue"; //package
    // name
    public static final Uri CONTENT_URI = new Uri.Builder()
            .scheme("content")
            .authority(AUTHORITY)
            .appendPath(TABLENAME)
            .build();

    //table attribute
    public static final class FavColumns implements BaseColumns {
        public static final String MOVIE_ID = "movie_id";
        public static final String TITLE = "title";
        public static final String DESC = "description";
        public static final String DATE = "date";
        public static final String POSTER_URI = "poster";
    }

    //function to get uri
    public static String getColumnString(Cursor cursor, String colname) {
        return cursor.getString(cursor.getColumnIndex(colname));
    }
}
