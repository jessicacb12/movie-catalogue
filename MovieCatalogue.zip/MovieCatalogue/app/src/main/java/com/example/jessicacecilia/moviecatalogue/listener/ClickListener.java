package com.example.jessicacecilia.moviecatalogue.listener;

import android.support.v7.widget.RecyclerView;
import android.view.View;

public interface ClickListener {
    void onClickedAdapter(View view, int position, RecyclerView recyclerView);
}
