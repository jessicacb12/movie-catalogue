package com.example.jessicacecilia.moviecatalogue;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.jessicacecilia.moviecatalogue.adapter.AdapterListener;
import com.example.jessicacecilia.moviecatalogue.entity.Movie;
import com.example.jessicacecilia.moviecatalogue.listener.CustomEventListener;
import com.example.jessicacecilia.moviecatalogue.model.GetMovie;

import java.util.ArrayList;


public class MovieDetailFragment extends Fragment {
    private ImageView btnUp;
    private ImageView imgBackdrop;
    private ImageView imgPoster;
    private TextView tvTitle;
    private TextView tvYear;
    private ImageView imgFav;
    private ProgressBar pbScore;
    private TextView tvScore;
    private TextView tvDesc;
    private TextView tvRuntimeTitle;
    private TextView tvRuntime;
    private MainActivity activity;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = (MainActivity) getActivity();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_movie_detail, container, false);
        activity.viewModel.setDetailFragment(this);


        //load from arguments
        Movie data = getArguments().getParcelable(AdapterListener.EXTRA_MOVIE);

        //up button
        btnUp = view.findViewById(R.id.btn_up);
        btnUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.viewModel.resetMovieDetail();
                activity.getSupportFragmentManager().popBackStackImmediate();
            }
        });

        imgBackdrop = view.findViewById(R.id.img_backdrop);
        imgPoster = view.findViewById(R.id.img_poster_detail);
        imgPoster.setImageBitmap(data.getPoster());
        tvTitle = view.findViewById(R.id.tv_title_detail);
        tvYear = view.findViewById(R.id.tv_year_detail);
        imgFav = view.findViewById(R.id.img_fav_detail);
        pbScore = view.findViewById(R.id.pb_score);
        tvScore = view.findViewById(R.id.tv_pb_score);
        tvDesc = view.findViewById(R.id.tv_desc_detail);
        tvRuntimeTitle = view.findViewById(R.id.tv_runtime_title);
        tvRuntime = view.findViewById(R.id.tv_runningtime);
        pbScore.setProgress(0);
        tvScore.setText("0");
        setInitialData(data);
        imgFav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CustomEventListener.setOnClickFavoriteListener(
                        data,
                        imgFav,
                        R.drawable.ic_bookmark_detail,
                        activity,
                        view
                );
                ArrayList<Movie> movies = new ArrayList<>();
                movies.add(data);
                activity.viewModel.refreshData(GetMovie.MOVIE_DETAIL, movies);
            }
        });

        //load the rest of data from network
        activity.viewModel.getMovieDetail(data.getId());
        return view;
    }

    public void setInitialData(Movie data) {
        tvTitle.setText(data.getTitle());
        tvYear.setText(
                getResources()
                        .getString(R.string.movie_year, data.getYear())
        );
        if (data.isFavorite()) {
            imgFav.setImageResource(R.drawable.ic_bookmarked);
        }
        tvDesc.setText(data.getDescription());
        tvRuntimeTitle.setVisibility(View.INVISIBLE);
        tvRuntime.setVisibility(View.INVISIBLE);
    }

    public void setLoadedData(Movie data) {
        tvRuntimeTitle.setVisibility(View.VISIBLE);
        tvRuntime.setText(
                getResources()
                        .getQuantityString(R.plurals.duration,
                                data.getRuntime(),
                                data.getRuntime())
        );
        tvRuntime.setVisibility(View.VISIBLE);
        tvScore.setText(Integer.toString(data.getUserScore()));
        pbScore.setProgress(data.getUserScore());
        imgBackdrop.setImageBitmap(data.getBackdrop());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        activity.viewModel.resetMovieDetail();
        activity.viewModel.setDetailFragment(null);
    }
}
