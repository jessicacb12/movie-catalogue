package com.example.jessicacecilia.moviecatalogue.view;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import android.os.Bundle;
import android.util.Log;

import com.example.jessicacecilia.moviecatalogue.FavoriteFragment;
import com.example.jessicacecilia.moviecatalogue.HomeFragment;
import com.example.jessicacecilia.moviecatalogue.MainActivity;
import com.example.jessicacecilia.moviecatalogue.MovieDetailFragment;
import com.example.jessicacecilia.moviecatalogue.SearchResultFragment;
import com.example.jessicacecilia.moviecatalogue.entity.Movie;
import com.example.jessicacecilia.moviecatalogue.model.AsyncTaskNetwork;
import com.example.jessicacecilia.moviecatalogue.model.GetMovie;

import java.util.ArrayList;

public class MovieViewModel extends ViewModel {
    private HomeFragment homeFragment;
    private SearchResultFragment searchResultFragment;
    private FavoriteFragment favoriteFragment;
    private MovieDetailFragment detailFragment;

    //info storage
    private MutableLiveData<ArrayList<Movie>> dataNowShowing;
    private MutableLiveData<ArrayList<Movie>> dataUpcoming;
    private MutableLiveData<ArrayList<Movie>> dataSearch;
    private String searchTitle = null;
    private MutableLiveData<ArrayList<Movie>> dataFav;
    private Movie movieDetail;

    //fragment getter setter
    public HomeFragment getHomeFragment() {
        return homeFragment;
    }

    public void setHomeFragment(HomeFragment homeFragment) {
        this.homeFragment = homeFragment;
    }

    public SearchResultFragment getSearchResultFragment() {
        return searchResultFragment;
    }

    public void setSearchResultFragment(SearchResultFragment searchResultFragment) {
        this.searchResultFragment = searchResultFragment;
    }

    public FavoriteFragment getFavoriteFragment() {
        return favoriteFragment;
    }

    public void setFavoriteFragment(FavoriteFragment favoriteFragment) {
        this.favoriteFragment = favoriteFragment;
    }

    public MovieDetailFragment getDetailFragment() {
        return detailFragment;
    }

    public void setDetailFragment(MovieDetailFragment detailFragment) {
        this.detailFragment = detailFragment;
    }

    //content to be displayed

    //home
    public void setNowShowing(MutableLiveData<ArrayList<Movie>> dataNowShowing) {
        this.dataNowShowing = dataNowShowing;
    }

    public void getNowShowing() {
        Log.d(MainActivity.TAG, "viewmodel get now showing");
        if (dataNowShowing == null) {
            homeFragment.setProgressVisible();
            dataNowShowing = new MutableLiveData<ArrayList<Movie>>();
            homeFragment.tryToConnect();
            loadData(GetMovie.NOW_SHOWING, null);
        } else {
            homeFragment.setAdapterNowShowing(dataNowShowing.getValue());
        }
    }

    public void setUpcoming(MutableLiveData<ArrayList<Movie>> dataUpcoming) {
        this.dataUpcoming = dataUpcoming;
    }

    public void getUpcoming() {
        if (dataUpcoming == null) {
            homeFragment.setProgressVisible();
            dataUpcoming = new MutableLiveData<ArrayList<Movie>>();
            homeFragment.tryToConnect();
            loadData(GetMovie.UPCOMING, null);
        } else {
            homeFragment.setProgressInvinsible();
            homeFragment.setAdapterUpcoming(dataUpcoming.getValue());
        }
    }

    public void refreshHomeData() {
        dataNowShowing = null;
        dataUpcoming = null;
        homeFragment.rvUpcoming.setAdapter(null);
        homeFragment.rvNowShowing.setAdapter(null);
        getNowShowing();
        getUpcoming();
    }

    //search
    public void getDataSearch(String searchTitle) {
        if (this.searchTitle == null || !this.searchTitle.equals(searchTitle)) {
            //start search
            this.searchTitle = searchTitle;
            if (dataSearch == null) {
                dataSearch = new MutableLiveData<ArrayList<Movie>>();
            }
            searchResultFragment.setProgressVisible();
            searchResultFragment.setProgress(0);
            searchResultFragment.tryToConnect();
            loadData(GetMovie.SEARCH_RESULT, searchTitle);
        } else {
            //use searched one
            searchResultFragment.edtSearch.setText(this.searchTitle);
            searchResultFragment.setAdapter(dataSearch.getValue());
        }
    }

    public void setDataSearch(MutableLiveData<ArrayList<Movie>> dataSearch) {
        this.dataSearch = dataSearch;
    }

    public String getSearchTitle() {
        return searchTitle;
    }

    //favorite
    public void getDataFav() {
        if (dataFav == null) {
            dataFav = new MutableLiveData<ArrayList<Movie>>();
            loadData(GetMovie.FAVORITE, "");
        } else {
            favoriteFragment.setAdapter(dataFav.getValue());
        }
    }

    public void setDataFav(MutableLiveData<ArrayList<Movie>> dataFav) {
        this.dataFav = dataFav;
    }

    public void refreshDataFav() {
        dataFav = null;
        favoriteFragment.rvFav.setAdapter(null);
        getDataFav();
    }

    //movie detail
    public void getMovieDetail(String id) {
        if (movieDetail == null) {
            loadData(GetMovie.MOVIE_DETAIL, id);
        } else {
            detailFragment.setInitialData(movieDetail);
            detailFragment.setLoadedData(movieDetail);
        }
    }

    public void setMovieDetail(Movie movieDetail) {
        this.movieDetail = movieDetail;
    }

    public void resetMovieDetail() {
        this.movieDetail = null;
    }

    //collection of setter
    public void refreshData(int code, ArrayList<Movie> data) {
        MutableLiveData<ArrayList<Movie>> movieList = new MutableLiveData<>();
        movieList.setValue(data);
        switch (code) {
            case GetMovie.NOW_SHOWING:
                setNowShowing(movieList);
                break;
            case GetMovie.UPCOMING:
                setUpcoming(movieList);
                break;
            case GetMovie.SEARCH_RESULT:
                setDataSearch(movieList);
                break;
            case GetMovie.MOVIE_DETAIL:
                setMovieDetail(data.get(0));
                break;
        }
    }

    //to load data either from network or db
    public void loadData(int dataCode, String identifier) {
        new AsyncTaskNetwork(createBundle(dataCode, identifier), this).execute();
    }

    //extra
    public static Bundle createBundle(int dataCode, String title) {
        Bundle bundle = new Bundle();
        bundle.putInt(GetMovie.EXTRA_URL_TYPE, dataCode);
        bundle.putString(GetMovie.EXTRA_IDENTIFIER, title);
        return bundle;
    }
}
