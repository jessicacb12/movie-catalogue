package com.example.jessicacecilia.moviecatalogue.database;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.util.Log;

import com.example.jessicacecilia.moviecatalogue.MainActivity;

import static com.example.jessicacecilia.moviecatalogue.database.DatabaseContract.CONTENT_URI;

public class MovieProvider extends ContentProvider {
    private QueryHelper queryHelper;
    private static final int PROVIDER_CODE = 77;
    private static final int PROVIDER_CODE_ID = 78;
    private static final UriMatcher uriMatch = new UriMatcher(UriMatcher.NO_MATCH);

    static {
        uriMatch.addURI(DatabaseContract.AUTHORITY,
                DatabaseContract.TABLENAME,
                PROVIDER_CODE);
        uriMatch.addURI(DatabaseContract.AUTHORITY,
                DatabaseContract.TABLENAME + "/*",
                PROVIDER_CODE_ID);
    }

    @Override
    public boolean onCreate() {
        queryHelper = new QueryHelper(getContext());
        queryHelper.open();
        return true;
    }

    @Override
    public Cursor query(@NonNull Uri uri,
                        String[] strings,
                        String s,
                        String[] strings1,
                        String s1) {
        Cursor cursor;
        switch (uriMatch.match(uri)) {
            case PROVIDER_CODE:
                Log.d(MainActivity.TAG, "Provider query");
                cursor = queryHelper.query();
                break;
            case PROVIDER_CODE_ID:
                Log.d(MainActivity.TAG, "Provider query id");
                cursor = queryHelper.queryById(uri.getLastPathSegment());
                break;
            default:
                cursor = null;
                break;
        }
        if (cursor != null) {
            cursor.setNotificationUri(getContext().getContentResolver(), uri);
        }
        return cursor;
    }

    @Override
    public String getType(Uri uri) {
        return MovieProvider.class.getSimpleName();
    }

    @Override
    public Uri insert(@NonNull Uri uri, ContentValues contentValues) {
        Log.d(MainActivity.TAG, "insert provider");
        long inserted = queryHelper.insert(contentValues);
        if (inserted > 0) {
            getContext().getContentResolver().notifyChange(uri, null);
        }
        return Uri.parse(CONTENT_URI + "/" + inserted);
    }

    @Override
    public int delete(@NonNull Uri uri,
                      String s,
                      String[] strings) {
        Log.d(MainActivity.TAG, "delete provider");
        int deleted = queryHelper.delete(uri.getLastPathSegment());
        if (deleted > 0) {
            getContext().getContentResolver().notifyChange(uri, null);
        }
        return deleted;
    }

    @Override
    public int update(@NonNull Uri uri,
                      ContentValues contentValues,
                      String s,
                      String[] strings) {
        return 0;
    }
}
