package com.example.jessicacecilia.favoritemovies.model;

import android.database.Cursor;
import android.os.AsyncTask;
import android.support.v4.content.ContentResolverCompat;
import android.support.v4.os.CancellationSignal;
import android.util.Log;

import com.example.jessicacecilia.favoritemovies.MainActivity;
import com.example.jessicacecilia.favoritemovies.database.DatabaseContract;
import com.example.jessicacecilia.favoritemovies.entity.Movie;

import java.util.ArrayList;

import static com.example.jessicacecilia.favoritemovies.database.DatabaseContract.CONTENT_URI;

public class AsyncTaskDB extends AsyncTask<Void, Void, Cursor> {
    private MainActivity activity;

    public AsyncTaskDB(MainActivity activity) {
        Log.d(MainActivity.TAG, "constructor loader");
        this.activity = activity;
    }

    @Override
    protected Cursor doInBackground(Void... voids) {
        CancellationSignal signal;
        synchronized (this) {
            signal = new CancellationSignal();
        }
        Cursor cursor = ContentResolverCompat
                .query(activity.getContentResolver(),
                        CONTENT_URI,
                        null,
                        null,
                        null,
                        null,
                        signal
                );
        return cursor;
    }

    @Override
    protected void onPostExecute(Cursor cursor) {
        super.onPostExecute(cursor);
        ArrayList<Movie> movies = converseIntoList(cursor);
        //load poster

        if (movies != null) {
            new AsyncTaskMovies(activity, movies, AsyncTaskMovies.LOAD_POSTER).execute();
        } else {
            activity.setProgressInvinsible();
            activity.setNoFavorite();
        }

    }

    private ArrayList<Movie> converseIntoList(Cursor cursor) {
        ArrayList<Movie> movies = new ArrayList<>();
        if (cursor != null) {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                String id = DatabaseContract.getColumnString(cursor,
                        DatabaseContract.FavColumns.MOVIE_ID);
                String title = DatabaseContract.getColumnString(cursor,
                        DatabaseContract.FavColumns.TITLE);
                Log.d(MainActivity.TAG, "get data " + title);
                String desc = DatabaseContract.getColumnString(cursor,
                        DatabaseContract.FavColumns.DESC);
                String date = DatabaseContract.getColumnString(cursor,
                        DatabaseContract.FavColumns.DATE);
                String posterUri = DatabaseContract.getColumnString(cursor,
                        DatabaseContract.FavColumns.POSTER_URI);

                Movie movie = new Movie(
                        id,
                        posterUri,
                        null,
                        title,
                        desc,
                        date,
                        true
                );
                movies.add(movie);
                cursor.moveToNext();
            }
        }
        return movies;
    }
}
