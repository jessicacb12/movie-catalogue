package com.example.jessicacecilia.favoritemovies;

import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.jessicacecilia.favoritemovies.database.DatabaseContract;
import com.example.jessicacecilia.favoritemovies.entity.Movie;

public class MovieDetailFragment extends Fragment {
    private ImageView btnUp;
    private ImageView imgBackdrop;
    private ImageView imgPoster;
    private TextView tvTitle;
    private TextView tvYear;
    private ImageView imgFav;
    private ProgressBar pbScore;
    private TextView tvScore;
    private TextView tvDesc;
    private TextView tvRuntimeTitle;
    private TextView tvRuntime;
    private MainActivity activity;

    public static final String EXTRA_MOVIE = "movieDetail";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = (MainActivity) getActivity();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_movie_detail, container, false);
        activity.viewModel.setDetailFragment(this);

        //load from arguments
        final int position = getArguments().getInt(EXTRA_MOVIE, 0);
        final Movie data = activity.viewModel.getDataFavDetail(position);

        //up button
        btnUp = view.findViewById(R.id.btn_up);
        btnUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.viewModel.resetMovieDetail();
                activity.getSupportFragmentManager().popBackStackImmediate();
            }
        });

        imgBackdrop = view.findViewById(R.id.img_backdrop);
        imgPoster = view.findViewById(R.id.img_poster_detail);
        imgPoster.setImageBitmap(data.getPoster());
        tvTitle = view.findViewById(R.id.tv_title_detail);
        tvYear = view.findViewById(R.id.tv_year_detail);
        imgFav = view.findViewById(R.id.img_fav_detail);
        pbScore = view.findViewById(R.id.pb_score);
        tvScore = view.findViewById(R.id.tv_pb_score);
        tvDesc = view.findViewById(R.id.tv_desc_detail);
        tvRuntimeTitle = view.findViewById(R.id.tv_runtime_title);
        tvRuntime = view.findViewById(R.id.tv_runningtime);
        pbScore.setProgress(0);
        tvScore.setText("0");
        setInitialData(data);
        imgFav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse(DatabaseContract.CONTENT_URI + "/" + data.getId());
                if (data.isFavorite()) {
                    Log.d(MainActivity.TAG, "fav deleted");
                    imgFav.setImageResource(R.drawable.ic_bookmark_detail);
                    activity.getContentResolver().delete(
                            uri,
                            null,
                            null
                    );
                    data.setFavorite(false);
                    activity.viewModel.deleteMovie(position);
                } else {
                    Log.d(MainActivity.TAG, "fav inserted");
                    imgFav.setImageResource(R.drawable.ic_bookmarked);
                    activity.getContentResolver().insert(
                            Uri.parse(DatabaseContract.CONTENT_URI + "/" + data.getId()),
                            DatabaseContract.contentValuesBuilder(data));
                    data.setFavorite(true);
                    activity.viewModel.insertMovie(data);
                }
            }
        });

        //load the rest of data from network
        activity.viewModel.getMovieDetail(data.getId());
        return view;
    }

    public void setInitialData(Movie data) {
        tvTitle.setText(data.getTitle());
        tvYear.setText(
                getResources()
                        .getString(R.string.movie_year, data.getYear())
        );
        if (data.isFavorite()) {
            imgFav.setImageResource(R.drawable.ic_bookmarked);
        }
        tvDesc.setText(data.getDescription());
        tvRuntimeTitle.setVisibility(View.INVISIBLE);
        tvRuntime.setVisibility(View.INVISIBLE);
    }

    public void setLoadedData(Movie data) {
        tvRuntimeTitle.setVisibility(View.VISIBLE);
        tvRuntime.setText(
                getResources()
                        .getQuantityString(R.plurals.duration,
                                data.getRuntime(),
                                data.getRuntime())
        );
        tvRuntime.setVisibility(View.VISIBLE);
        tvScore.setText(Integer.toString(data.getUserScore()));
        pbScore.setProgress(data.getUserScore());
        imgBackdrop.setImageBitmap(data.getBackdrop());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        activity.viewModel.resetMovieDetail();
        activity.viewModel.setDetailFragment(null);
    }
}
