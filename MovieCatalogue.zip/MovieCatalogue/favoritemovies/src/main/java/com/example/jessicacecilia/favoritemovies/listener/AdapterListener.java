package com.example.jessicacecilia.favoritemovies.listener;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.example.jessicacecilia.favoritemovies.MainActivity;
import com.example.jessicacecilia.favoritemovies.MovieDetailFragment;
import com.example.jessicacecilia.favoritemovies.R;
import com.example.jessicacecilia.favoritemovies.entity.Movie;

import java.util.ArrayList;

public class AdapterListener {
    private final RecyclerView recyclerView;
    private ClickListener clickListener;

    private View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if (clickListener != null) {
                RecyclerView.ViewHolder holder = recyclerView.getChildViewHolder(view);
                clickListener.onClickedAdapter(view, holder.getAdapterPosition(), recyclerView);
            }
        }
    };

    private AdapterListener(RecyclerView recyclerView) {
        this.recyclerView = recyclerView;
        recyclerView.setTag(R.id.event_listener, this);
        recyclerView.addOnChildAttachStateChangeListener(new RecyclerView.OnChildAttachStateChangeListener() {
            @Override
            public void onChildViewAttachedToWindow(@NonNull View view) {
                if (clickListener != null) {
                    view.setOnClickListener(onClickListener);
                }
            }

            @Override
            public void onChildViewDetachedFromWindow(@NonNull View view) {
            }
        });
    }

    //only call this function to make listener
    public static void toMovieDetail(
            RecyclerView rv,
            final ArrayList<Movie> movies,
            final MainActivity activity
    ) {
        makeAdapterListener(
                rv,
                new ClickListener() {
                    @Override
                    public void onClickedAdapter(View view, int position,
                                                 RecyclerView recyclerView) {
                        directlyOpenDetail(activity, movies, position);
                    }
                }
        );
    }

    private static void directlyOpenDetail(MainActivity activity,
                                           ArrayList<Movie> movies,
                                           int position) {
        Bundle bundle = new Bundle();
        bundle.putInt(MovieDetailFragment.EXTRA_MOVIE, position);
        MovieDetailFragment detailFragment = new MovieDetailFragment();
        detailFragment.setArguments(bundle);
        activity.getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.fragment_container,
                        detailFragment,
                        MovieDetailFragment.class.getSimpleName())
                .addToBackStack(MovieDetailFragment.class.getSimpleName())
                .commit();
    }

    private static AdapterListener addTo(RecyclerView view) {
        AdapterListener eventListener = (AdapterListener) view.getTag(R.id.event_listener);
        if (eventListener == null) {
            eventListener = new AdapterListener(view);
        }
        return eventListener;
    }

    private static void makeAdapterListener(RecyclerView recyclerView, ClickListener listener) {
        AdapterListener eventListener = addTo(recyclerView);
        eventListener.clickListener = listener;
    }
}
