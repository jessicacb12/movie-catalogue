package com.example.jessicacecilia.favoritemovies.model;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.example.jessicacecilia.favoritemovies.MainActivity;
import com.example.jessicacecilia.favoritemovies.MovieDetailFragment;
import com.example.jessicacecilia.favoritemovies.entity.Movie;

import java.util.ArrayList;

public class MovieViewModel extends ViewModel {
    private MainActivity favActivity;
    private MovieDetailFragment detailFragment;

    //info storage
    private MutableLiveData<ArrayList<Movie>> dataFav;
    private Movie movieDetail;

    //fragment getter setter

    public void setFavActivity(MainActivity favActivity) {
        this.favActivity = favActivity;
    }

    public MovieDetailFragment getDetailFragment() {
        return detailFragment;
    }

    public void setDetailFragment(MovieDetailFragment detailFragment) {
        this.detailFragment = detailFragment;
    }

    //get data
    public Movie getDataFavDetail(int i) {
        return dataFav.getValue().get(i);
    }

    public void getDataFav() {
        favActivity.tryToGetFav();
        favActivity.rvMovies.setAdapter(null);
        if (dataFav == null) {
            loadData(GetMovie.LOAD_DB, "");
        } else {
            favActivity.fillAdapter(dataFav.getValue());
        }
    }

    public void setDataFav(MutableLiveData<ArrayList<Movie>> dataFav) {
        this.dataFav = dataFav;
    }

    public void refreshDataFav() {
        dataFav = null;
        getDataFav();
    }

    public void getMovieDetail(String id) {
        if (movieDetail == null) {
            loadData(GetMovie.LOAD_NETWORK, id);
        } else {
            detailFragment.setLoadedData(movieDetail);
        }
    }

    public void setMovieDetail(Movie movieDetail) {
        this.movieDetail = movieDetail;
    }

    public void resetMovieDetail() {
        movieDetail = null;
        detailFragment = null;
    }

    //to change viewmodel fav data based on action in movie detail
    public void deleteMovie(int position) {
        ArrayList<Movie> movies = dataFav.getValue();
        movies.remove(position);
        dataFav.setValue(movies);
    }

    public void insertMovie(Movie movie) {
        ArrayList<Movie> movies = dataFav.getValue();
        movies.add(movie);
        dataFav.setValue(movies);
    }

    //to load data either from network or db
    private void loadData(int dataCode, String identifier) {
        if (dataCode == GetMovie.LOAD_DB) {
            favActivity.setProgressVisible();
            new AsyncTaskDB(favActivity).execute();
        } else {
            new AsyncTaskMovies(
                    detailFragment.getActivity(),
                    AsyncTaskMovies.LOAD_MOVIE).execute(identifier);
        }
    }
}
