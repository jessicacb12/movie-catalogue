package com.example.jessicacecilia.favoritemovies;

import android.arch.lifecycle.ViewModelProviders;
import android.os.Handler;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.jessicacecilia.favoritemovies.adapter.MovieAdapter;
import com.example.jessicacecilia.favoritemovies.entity.Movie;
import com.example.jessicacecilia.favoritemovies.listener.AdapterListener;
import com.example.jessicacecilia.favoritemovies.model.MovieViewModel;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public RecyclerView rvMovies;
    public TextView tvNoFav;
    public MovieViewModel viewModel;
    private ProgressBar progressBar;
    private SwipeRefreshLayout swipeRefreshLayout;
    public static final String TAG = "trace";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        viewModel = ViewModelProviders.of(this).get(MovieViewModel.class);
        viewModel.setFavActivity(this);

        swipeRefreshLayout = findViewById(R.id.swipe_refresh);

        //progress
        progressBar = findViewById(R.id.progress_bar);
        setProgressInvinsible();

        tvNoFav = findViewById(R.id.tv_no_conn_fav);
        rvMovies = findViewById(R.id.rv_fav);
        rvMovies.setLayoutManager(
                new LinearLayoutManager(
                        this,
                        LinearLayoutManager.HORIZONTAL,
                        false)
        );

        //load data
        viewModel.getDataFav();

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                new Handler().post(new Runnable() {
                    @Override
                    public void run() {
                        viewModel.refreshDataFav();
                        swipeRefreshLayout.setRefreshing(false);
                    }
                });
            }
        });
    }

    //set adapter
    public void fillAdapter(final ArrayList<Movie> movies) {
        Log.d(MainActivity.TAG, "bersiap mengisi adapter");
        setProgressInvinsible();
        rvMovies.setAdapter(new MovieAdapter(movies, this));
        AdapterListener.toMovieDetail(
                rvMovies,
                movies,
                this
        );
    }

    public void tryToGetFav() {
        tvNoFav.setVisibility(View.INVISIBLE);
    }

    public void publishProgress(int progress) {
        progressBar.setProgress(progress);
    }

    public void setProgressVisible() {
        progressBar.setVisibility(View.VISIBLE);
    }

    public void setProgressInvinsible() {
        progressBar.setVisibility(View.INVISIBLE);
    }

    public void setNoFavorite() {
        tvNoFav.setVisibility(View.VISIBLE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        viewModel.getDataFav();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
