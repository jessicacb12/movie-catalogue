package com.example.jessicacecilia.favoritemovies.database;

import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.provider.BaseColumns;

import com.example.jessicacecilia.favoritemovies.entity.Movie;

public class DatabaseContract {
    public static final String TABLENAME = "favorite";
    public static final String AUTHORITY = "com.example.jessicacecilia.moviecatalogue"; //package
    // name
    public static final Uri CONTENT_URI = new Uri.Builder()
            .scheme("content")
            .authority(AUTHORITY)
            .appendPath(TABLENAME)
            .build();

    //table attribute
    public static final class FavColumns implements BaseColumns {
        public static final String MOVIE_ID = "movie_id";
        public static final String TITLE = "title";
        public static final String DESC = "description";
        public static final String DATE = "date";
        public static final String POSTER_URI = "poster";
    }

    //function to get uri
    public static String getColumnString(Cursor cursor, String colname) {
        return cursor.getString(cursor.getColumnIndex(colname));
    }

    //content value creator
    public static ContentValues contentValuesBuilder(Movie movie) {
        ContentValues cv = new ContentValues();
        cv.put(DatabaseContract.FavColumns.MOVIE_ID, movie.getId());
        cv.put(DatabaseContract.FavColumns.TITLE, movie.getTitle());
        cv.put(DatabaseContract.FavColumns.DESC, movie.getDescription());
        cv.put(DatabaseContract.FavColumns.DATE, movie.getReleaseDate());
        cv.put(DatabaseContract.FavColumns.POSTER_URI, movie.getPosterUri());

        return cv;
    }
}
