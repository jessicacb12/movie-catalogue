package com.example.jessicacecilia.favoritemovies.model;

import android.arch.lifecycle.MutableLiveData;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.example.jessicacecilia.favoritemovies.MainActivity;
import com.example.jessicacecilia.favoritemovies.MovieDetailFragment;
import com.example.jessicacecilia.favoritemovies.entity.Movie;

import java.util.ArrayList;


public class AsyncTaskMovies extends AsyncTask<String, Integer, ArrayList<Movie>> {
    private Context context;
    private ArrayList<Movie> movies;
    private int code;
    private boolean hasResult = false;

    public static final int LOAD_MOVIE = 31;
    public static final int LOAD_POSTER = 32;

    public AsyncTaskMovies(Context context, int code) {
        this.context = context;
        this.code = code;
    }


    //constructor to load poster
    public AsyncTaskMovies(Context context, ArrayList<Movie> movies, int code) {
        this(context, code);
        this.movies = movies;
    }

    @Override
    protected ArrayList<Movie> doInBackground(String... titles) {
        ArrayList<Movie> movieList = null;
        GetMovie getMovie = new GetMovie(context);
        if (code == LOAD_MOVIE) {
            movieList = getMovie.getSingleFromHTTP(titles[0]);
        } else { //load poster
            movieList = getMovie.putPosters(movies);
        }
        int progress = 0;
        while (!hasResult) {
            hasResult = getMovie.processFinished();
            if (code == LOAD_POSTER) {
                publishProgress(progress);
                progress = (progress == 100) ? 0 : (progress + 50);
            }
        }
        Log.d(MainActivity.TAG, "do in background selesai");
        return movieList;
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
        if (code == LOAD_POSTER) {
            MainActivity activity = (MainActivity) context;
            try {
                Thread.sleep(100);
                activity.publishProgress(values[0]);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void onPostExecute(ArrayList<Movie> movies) {
        super.onPostExecute(movies);
        Log.d(MainActivity.TAG, "masuk on post execute");

        MainActivity activity = (MainActivity) context;
        if (code == LOAD_MOVIE) {
            Log.d(MainActivity.TAG, "memasang detil film");
            MovieDetailFragment fragment = activity.viewModel.getDetailFragment();
            Movie movie = movies.get(0);
            fragment.setLoadedData(movie);
            activity.viewModel.setMovieDetail(movie);
        } else {
            MutableLiveData<ArrayList<Movie>> data = new MutableLiveData<>();
            data.setValue(movies);
            activity.viewModel.setDataFav(data);
            activity.fillAdapter(movies);
            Log.d(MainActivity.TAG, "get poster selesai");
        }

    }
}
