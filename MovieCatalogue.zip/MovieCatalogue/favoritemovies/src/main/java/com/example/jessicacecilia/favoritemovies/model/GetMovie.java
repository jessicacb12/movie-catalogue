package com.example.jessicacecilia.favoritemovies.model;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import com.example.jessicacecilia.favoritemovies.BuildConfig;
import com.example.jessicacecilia.favoritemovies.MainActivity;
import com.example.jessicacecilia.favoritemovies.entity.Movie;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.json.JSONObject;

import java.net.URL;
import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;


public class GetMovie {
    private static final String API_KEY = BuildConfig.ApiKey;
    public static final int LOAD_NETWORK = 21;
    public static final int LOAD_DB = 22;

    private ArrayList<Movie> movieList;
    private boolean isProcessFinished = false;
    private JSONObject responseObject;
    public static final String POSTER_URI = "http://image.tmdb.org/t/p/w185";
    private final String BACKDROP_URI = "http://image.tmdb.org/t/p/w780";
    private final String MOVIE_URI =
            "https://api.themoviedb.org/3/movie/%s?api_key=" + API_KEY + "&language=en-US";
    private Context context;


    public GetMovie(Context context) {
        this.context = context;
    }

    public boolean processFinished() {
        return isProcessFinished;
    }

    //get single movie detail
    public ArrayList<Movie> getSingleFromHTTP(String id) {
        AsyncHttpClient client = new AsyncHttpClient();
        String url = String.format(MOVIE_URI, id);
        movieList = new ArrayList<Movie>();
        client.get(url, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                try {
                    responseObject = new JSONObject(new String(responseBody));

                    double userScore = Double
                            .parseDouble(responseObject
                                    .getString("vote_average")) * 10;
                    int runtime = responseObject.getInt("runtime");

                    String backdrop = responseObject.getString("backdrop_path");
                    String backdropUri = BACKDROP_URI + backdrop;
                    Bitmap imgBackdrop = null;
                    if (backdrop != null || !backdrop.equals("null")) {
                        imgBackdrop = getImageBitmap(backdropUri);
                    }

                    movieList.add(new Movie(imgBackdrop, ((int) userScore), runtime));
                } catch (Exception e) {
                    e.printStackTrace();
                }
                isProcessFinished = true;
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody,
                                  Throwable error) {
                isProcessFinished = true;
            }

            @Override
            public boolean getUseSynchronousMode() {
                return false;
            }
        });
        return movieList;
    }

    public ArrayList<Movie> putPosters(ArrayList<Movie> movies) {
        for (Movie movie : movies) {
            Bitmap poster = getImageBitmap(POSTER_URI + movie.getPosterUri());
            movie.setPoster(poster);
        }
        Log.d(MainActivity.TAG, "Poster sudah dipasang");
        isProcessFinished = true;
        return movies;
    }

    public Bitmap getImageBitmap(String image) {
        Bitmap bitmap = null;
        try {
            URL url = new URL(image);
            bitmap = BitmapFactory.decodeStream(url.openConnection().getInputStream());

        } catch (Exception e) {
            e.printStackTrace();
        }

        Log.d(MainActivity.TAG, "gambar telah diambil");

        //if from main activity
        if (context instanceof MainActivity) {
            Log.d(MainActivity.TAG, "instance main activity");
            isProcessFinished = true;
        }
        return bitmap;
    }
}
