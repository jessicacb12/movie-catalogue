package com.example.jessicacecilia.favoritemovies.adapter;

import android.arch.lifecycle.MutableLiveData;
import android.graphics.Bitmap;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.jessicacecilia.favoritemovies.MainActivity;
import com.example.jessicacecilia.favoritemovies.R;
import com.example.jessicacecilia.favoritemovies.database.DatabaseContract;
import com.example.jessicacecilia.favoritemovies.entity.Movie;

import java.util.ArrayList;

import static com.example.jessicacecilia.favoritemovies.database.DatabaseContract.CONTENT_URI;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.MovieViewHolder> {
    private ArrayList<Movie> movieList;
    private MainActivity activity;

    public MovieAdapter(ArrayList<Movie> movieList, MainActivity activity) {
        Log.d(MainActivity.TAG, "constructor adapter");
        this.activity = activity;
        this.movieList = movieList;
    }

    @NonNull
    @Override
    public MovieViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.movie_item,
                viewGroup, false);
        return new MovieViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MovieViewHolder movieViewHolder, int i) {
        final Movie movie = movieList.get(i);

        movieViewHolder.tvTitle.setText(movie.getTitle());
        Log.d(MainActivity.TAG, "pasang " + movie.getTitle());
        //setting poster
        Bitmap poster = movie.getPoster();

        if (poster != null) {
            movieViewHolder.imgPoster.setImageBitmap(poster);
        } else {
            movieViewHolder.imgPoster.setImageResource(R.drawable.ic_local_movies_black_24dp);
        }

        //setting favorite button
        movieViewHolder.imgFav.setImageResource(R.drawable.ic_bookmarked);


        movieViewHolder.imgFav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickFavoriteIcon(movieViewHolder.imgFav, movie);
            }
        });
    }

    @Override
    public int getItemCount() {
        return movieList.size();
    }

    private void removeItem(Movie movie) {
        movieList.remove(movie);
        setAgainViewModel();
        notifyDataSetChanged();
    }

    private void addItem(Movie movie) {
        movieList.add(movie);
        setAgainViewModel();
        notifyDataSetChanged();
    }

    private void setAgainViewModel() {
        MutableLiveData<ArrayList<Movie>> data = new MutableLiveData<>();
        data.setValue(movieList);
        activity.viewModel.setDataFav(data);
    }

    //on click favorite icon
    private void onClickFavoriteIcon(final ImageView favIcon,
                                     final Movie movie) {
        //delete from db
        favIcon.setImageResource(R.drawable.ic_bookmark);
        movie.setFavorite(false);
        activity.getContentResolver().delete(
                Uri.parse(CONTENT_URI + "/" + movie.getId()),
                null,
                null
        );
//        //show snackbar
        Snackbar.make(
                activity.rvMovies,
                R.string.delete_fav,
                Snackbar.LENGTH_SHORT
        )
                .setAction(
                        R.string.undo_delete_fav,
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                addItem(movie);
                                activity.getContentResolver().insert(
                                        Uri.parse(CONTENT_URI + "/" + movie.getId()),
                                        DatabaseContract.contentValuesBuilder(movie)
                                );
                                favIcon.setImageResource(R.drawable.ic_bookmarked);
                            }
                        }
                )
                .show();
//        //refresh layout
        removeItem(movie);
    }

    //viewholder which control display
    public static class MovieViewHolder extends RecyclerView.ViewHolder {
        public TextView tvTitle;
        public ImageView imgPoster;
        public ImageView imgFav;

        private MovieViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tv_title_grid);
            imgPoster = itemView.findViewById(R.id.img_poster_grid);
            imgFav = itemView.findViewById(R.id.btn_fav_grid);
        }
    }
}
